<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cadastro De Músicos</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <script>
        function validar(dom,tipo){
	        switch(tipo){
        		case'num':var regex=/[A-Za-z]/g;break;
        		case'text':var regex=/\d/g;break;
	        }
	        dom.value=dom.value.replace(regex,'');
        }
    </script>
<main>
  <div class="container">
   
    <form action="cad-musico.php" method="post">
      <div class="form-row">
        <div class="form-group col-md-12">
          <h1>Cadastro de Músicos</h1>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-8">
          <label for="nome">Nome:</label>
          <input type="text" class="form-control" id="nome" placeholder="Nome" name="nome" onkeyup="validar(this,'text');" required>
        </div>

        <div class="form-group col-md-4">
          <label for="sobrenome">Sobrenome:</label>
          <input type="text" class="form-control" id="sobrenome" placeholder="Sobrenome" name="sobrenome" onkeyup="validar(this,'text');" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="email">Email:</label>
          <input type="email" class="form-control" id="email" placeholder="E-mail" name="email" required>
        </div>

      
        <div class="form-group col-md-6">
          <label for="senha">Senha:</label>
          <input type="password" class="form-control" id="senha" placeholder="Defina sua senha" name="senha" required>
        </div>

        <div class="form-group col-md-4">
          <label for="cpf">CPF:</label>
          <input type="text" class="form-control" id="cpf" placeholder="CPF (Somente números)" name="cpf" onkeyup="validar(this,'num');" maxlength="11"required>
        </div>
        
        <div class="form-row">
          <div class="form-group col-md-4">
            <label for="telefone">Telefone:</label>
            <input type="text" class="form-control" id="telefone" placeholder="Telefone (Somente números)" name="telefone" onkeyup="validar(this,'num');" maxlength="13" required>
          </div>
        </div>

        <div class="form-group col-md-2">
          <label for="gênero">Gênero Musical:</label>
          <input type="text" class="form-control" id="Gênero" placeholder="Gênero Musical" name="genero" onkeyup="validar(this,'text');" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-5">
          <label for="data">Data de Nascimento:</label>
          <input type="text" class="form-control" id="data" placeholder="Data de Nascimento (Somente números)" name="data" onkeyup="validar(this,'num');" maxlength="8"required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-4">
          <label for="endereco">Endereço:</label>
          <input type="text" class="form-control" id="endereco" placeholder="Endereço" name="endereco" required>
        </div>
      </div>
      
    
      
      <div class="form-row">
        <div class="form-group col-md-2">
          <button type="submit" class="btn btn-primary">Cadastrar</button>
        </div>
      </div>
    </form>
  </div>

</main>
<br><br>
 </body>
</html>
<?php include "cabecalho.php"; ?>




















</body>
</html>
