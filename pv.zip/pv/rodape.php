<link rel="shortcut icon" href="img/logoo.png">

	<link rel="stylesheet" href="web-fonts-with-css/css/fontawesome-all.min.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/
	bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/
	font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/
	jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/
	bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/estilo1.css">
	
	
<div id="home6">
	<div class="landing-text">
	</div>
</div>
<div class="navbar navbar-inverse navbar-fexed-bottom" role="navigation">
	<div class="container">
		<div class="aslap">
			<p id="rodape" style="color: white;">&copy; 2018 Músicos de Aluguel.</p>

				<ul id="icone">
	 				<a href="https://github.com/" class = "fab fa-github-square"  target="_blank" style="color:black;background-color:white;"> <a/>

					<a href="https://pt-br.facebook.com/" class="fab fa-facebook" target="_blank" style="color: #3b5998;background-color:white "></a>

					<a href="https://twitter.com/signup/" class="fab fa-twitter-square" target="_blank" style="color:#00aced;background-color:white;"></a>

					<a href="https://plus.google.com/u/0/" class="fab fa-google-plus" target="_blank" style="color:white ;background-color:#dd4b39;"></a>
			</ul>
		</div>
	</div>
</div>